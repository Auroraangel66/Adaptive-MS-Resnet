#import tensorflow as tf
import tensorflow.compat.v1 as tf
tf.disable_v2_behavior()
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.io import savemat
from scipy.interpolate import griddata
from wave_equation_model import Sampler, Wave_Equation
if __name__ == '__main__':
    def u(x):
        """
        :param x: x = (t, x)
        """
        return np.sin(np.pi*x[:, 1:2]) * np.cos(2 * np.pi * x[:, 0:1]) + 0.5* np.sin(4*np.pi*x[:, 1:2]) * np.cos(8 * np.pi * x[:, 0:1])
    def u_t(x):
        return -2*np.pi*np.sin(np.pi*x[:, 1:2]) * np.sin(2 * np.pi * x[:, 0:1]) -4*np.pi* np.sin(4*np.pi*x[:, 1:2]) * np.sin(8 * np.pi * x[:, 0:1])
    def u_x(x):
        return np.pi*np.cos(np.pi*x[:, 1:2]) * np.cos(2 * np.pi * x[:, 0:1]) + 2*np.pi* np.cos(4*np.pi*x[:, 1:2]) * np.cos(8 * np.pi * x[:, 0:1])
    def u_tt(x):
        return -4*(np.pi)**2*np.sin(np.pi*x[:, 1:2]) * np.cos(2 * np.pi * x[:, 0:1]) -32*(np.pi)**2* np.sin(4*np.pi*x[:, 1:2]) * np.cos(8 * np.pi * x[:, 0:1])
    def u_xx(x):
        return -(np.pi)**2*np.sin(np.pi*x[:, 1:2]) * np.cos(2 * np.pi * x[:, 0:1]) -8*(np.pi)**2*np.sin(4*np.pi*x[:, 1:2]) * np.cos(8 * np.pi * x[:, 0:1])
    def f(x):

        return u_tt(x) -4*u_xx(x)
    def operator(u, t, x, sigma_t=1.0, sigma_x=1.0):
        u_t = tf.gradients(u, t)[0] / sigma_t
        u_x = tf.gradients(u, x)[0] / sigma_x
        u_tt = tf.gradients(u_t, t)[0] / sigma_t
        u_xx = tf.gradients(u_x, x)[0] / sigma_x
        residual = u_tt -4*u_xx
        return residual

    # Domain boundaries
    ics_coords = np.array([[0.0, 0.0],
                           [0.0, 1.0]])
    bc1_coords = np.array([[0.0, 0.0],
                           [1.0, 0.0]])
    bc2_coords = np.array([[0.0, 1.0],
                           [1.0, 1.0]])
    bc3_coords = np.array([[0.0, 0.0],
                           [0.0, 1.0]])
    dom_coords = np.array([[0.0, 0.0],
                           [1.0, 1.0]])

    # Create initial conditions samplers
    ics_sampler = Sampler(2, ics_coords, lambda x: u_t(x), name='Initial Condition')

    # Create boundary conditions samplers
    bc1 = Sampler(2, bc1_coords, lambda x: u(x), name='Dirichlet BC1')
    bc2 = Sampler(2, bc2_coords, lambda x: u(x), name='Dirichlet BC2')
    bc3 = Sampler(2, bc3_coords, lambda x: u(x), name='Dirichlet BC3')
    bcs_sampler = [bc1, bc2, bc3]

    # Create residual sampler
    res_sampler = Sampler(2, dom_coords, lambda x: f(x), name='Forcing')
    u_sampler=Sampler(2, dom_coords, lambda x: u(x), name='Forcing')
    # Define model
    # layers = [3, 30, 30,30, 30, 30,30, 1]
    layers = [2, 200, 200, 200, 200, 200,1]
    mode = 'M2'          # Method: 'M1', 'M2', 'M3', 'M4'
    stiff_ratio = False  # Log the eigenvalues of Hessian of losses
    dir = "wave_eqs"
    # Test data
    # nn = 100
    # t = np.linspace(dom_coords[0, 0], dom_coords[1, 0], nn)[:, None]
    # x = np.linspace(dom_coords[0, 1], dom_coords[1, 1], nn)[:, None]
    # t, x = np.meshgrid(t, x)
    # X_star = np.hstack((t.flatten()[:, None], x.flatten()[:, None]))
    nn = 100
    t11 = np.linspace(0, 1, nn)[:, None]
    x11 = np.linspace(0, 1, nn)[:, None]
    t, x = np.meshgrid(t11, x11)
    X_star = np.hstack((t.flatten()[:, None], x.flatten()[:, None]))
    # Exact solution
    u_star = u(X_star)
    f_star = f(X_star)   #将精确解带进去可以得到f
    model = Wave_Equation(dir,layers, operator, ics_sampler, bcs_sampler, res_sampler, u_sampler, mode, stiff_ratio, u_star,X_star)
    # Train model
    model.train(nIter=100000, batch_size=128)
    # Predictions
    u_pred = model.predict_u(X_star)
    error_u = np.linalg.norm(u_star - u_pred, 2) / np.linalg.norm(u_star, 2)

    print('Relative L2 error_u: {:.2e}'.format(error_u))
    data_save = {}
    data_save['step'] = np.array(model.step_log).reshape(len(model.step_log), 1)
    data_save['loss'] = np.array(model.loss_log).reshape(len(model.loss_log), 1)
    data_save['constant_bcs_val'] = np.array(model.adaptive_constant_bcs_log).reshape(
        len(model.adaptive_constant_bcs_log), 1)
    data_save['constant_ics_val'] = np.array(model.adaptive_constant_ics_log).reshape(
        len(model.adaptive_constant_ics_log), 1)
    data_save['X'] = X_star
    data_save['x11'] = t11
    data_save['x22'] = x11
    data_save['err_l2r'] = np.array(model.err_l2r_log).reshape(len(model.err_l2r_log), 1)
    data_save['u_test'] = u_star
    data_save['u_pred'] = u_pred
    savemat(model.dir + '/data.mat', data_save)

    ### Plot ###

    # Test data
    U_star = griddata(X_star, u_star.flatten(), (t, x), method='nearest')
    F_star = griddata(X_star, f_star.flatten(), (t, x), method='nearest')

    U_pred = griddata(X_star, u_pred.flatten(), (t, x), method='nearest')

    fig_1 = plt.figure(1, figsize=(18, 5))
    plt.subplot(1, 3, 1)
    plt.pcolor(t, x, U_star, cmap='jet')
    plt.colorbar()
    plt.xlabel('$t$')
    plt.ylabel('$x$')
    plt.title('Exact u(x)')

    plt.subplot(1, 3, 2)
    plt.pcolor(t, x, U_pred, cmap='jet')
    plt.colorbar()
    plt.xlabel('$t$')
    plt.ylabel('$x$')
    plt.title('Predicted u(x)')

    plt.subplot(1, 3, 3)
    plt.pcolor(t, x, np.abs(U_star - U_pred), cmap='jet')
    plt.colorbar()
    plt.xlabel('$t$')
    plt.ylabel('$x$')
    plt.title('Absolute error')
    plt.tight_layout()
    plt.show()

    # Loss
    loss_r = model.loss_r_log
    loss_bcs = model.loss_bcs_log
    loss_ics = model.loss_ics_log


    fig_2 = plt.figure(2)
    ax = fig_2.add_subplot(1, 1, 1)
    ax.plot(loss_r, 'g',label='$\mathcal{L}_{r}$')
    ax.plot(loss_bcs,'b', label='$\mathcal{L}_{bcs}$')
    ax.plot(loss_ics,'r', label='$\mathcal{L}_{ics}$')
    ax.set_yscale('log')
    ax.set_xlabel('iterations')
    ax.set_ylabel('Loss')
    plt.legend()
    plt.tight_layout()
    plt.grid(linestyle=":")
    plt.show()

    # Adaptive Constant
    adaptive_constant_ics = model.adaptive_constant_ics_log
    adaptive_constant_bcs = model.adaptive_constant_bcs_log

    fig_3 = plt.figure(3)
    ax = fig_3.add_subplot(1, 1, 1)
    ax.plot(adaptive_constant_ics,'r', label='$\lambda_{u_0}$')
    ax.plot(adaptive_constant_bcs,'b', label='$\lambda_{u_b}$')
    ax.set_yscale('log')
    ax.set_xlabel('iterations')
    ax.set_ylabel('adaptive_constant')
    plt.legend()
    plt.tight_layout()
    plt.grid(linestyle=":")
    plt.show()

    # Gradients at the end of training
    data_gradients_ics = model.dict_gradients_ics_layers
    data_gradients_bcs = model.dict_gradients_bcs_layers
    data_gradients_res = model.dict_gradients_res_layers

    num_hidden_layers = len(layers) - 1
    cnt = 1
    fig_4 = plt.figure(4, figsize=(13, 8))
    for j in range(num_hidden_layers-1):
        ax = plt.subplot(2, 3, cnt)
        gradients_ics = data_gradients_ics['layer_' + str(j + 1)][-1]
        gradients_bcs = data_gradients_bcs['layer_' + str(j + 1)][-1]
        gradients_res = data_gradients_res['layer_' + str(j + 1)][-1]
        sns.distplot(gradients_ics, hist=False,
                     kde_kws={"shade": False},
                     norm_hist=True, label=r'$\nabla_\theta \lambda_{u_0}\mathcal{L}_{u_0}$')
        sns.distplot(gradients_bcs, hist=False,
                     kde_kws={"shade": False},
                     norm_hist=True, label=r'$\nabla_\theta \lambda_{u_b} \mathcal{L}_{u_b}$')
        sns.distplot(gradients_res, hist=False,
                     kde_kws={"shade": False},
                     norm_hist=True, label=r'$\nabla_\theta \mathcal{L}_r$')

        ax.set_title('Layer {}'.format(j + 1))
        ax.set_yscale('symlog')
        ax.set_xlim([-1, 1])
        ax.set_ylim([0, 500])
        # ax.get_legend().remove()
        cnt += 1
    handles, labels = ax.get_legend_handles_labels()
    fig_4.legend(handles, labels, loc="upper left", bbox_to_anchor=(0.3, 0.01),
                 borderaxespad=0, bbox_transform=fig_4.transFigure, ncol=3)
    plt.tight_layout()
    plt.show()


    ##############相对误差
    relatie_error = model.err_l2r_log
    fig_5 = plt.figure(5)
    ax = fig_5.add_subplot(1, 1, 1)
    ax.plot(relatie_error, 'r')
    # ax.set_yscale('log')
    ax.set_xlabel('iterations')
    ax.set_ylabel('relative_error')
    plt.legend()
    plt.grid(linestyle=":")
    plt.tight_layout()
    plt.show()












